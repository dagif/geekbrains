// 1. Написать функцию loop, которая будет принимать параметры: times (значение по умолчанию = 0), callback (значение по умолчанию = null) 
// и будет в цикле (times раз), вызывать функцию callback. Если функцию не передана, то цикл не должен отрабатывать ни разу. 
// Покажите применение этой функции

const loop = (times = 0, callback = null) => {
    if (!callback) {
      return;
    }
    for (let i = 0; i < times; i++) {
      callback();
    }
  };
  
//отработает 10 раз
loop(10, () => console.log("do callback"));  

//не отработает ни разу
loop(10, () => console.log("do callback"));  


// 2. Написать функцию calculateArea, которая будет принимать параметры, для вычисления площади (можете выбрать какую то конкретную фигуру, а можете,
// основываясь на переданных параметрах, выполнять требуемый алгоритм вычисления площади для переданной в параметрах фигуры) и возвращать
// объект вида: { area, figure, input }, где area - вычисленная площадь, figure - название фигуры, для которой вычислялась площадь, input - входные
// параметры, по которым было произведено вычисление.

const calculateArea = (width, heihgt) => {
    const area = width * heihgt;
    const data = {
      area: area,
      figure: "Rectangle",
      input: {
        width: width,
        heihgt: heihgt
      }
    };
    return data;
  };
  
  console.log(calculateArea(3, 4));
  

// 3. Необходимо написать иерархию классов вида:
// Human -> Employee -> Developer
// Human -> Employee -> Manager
// Каждый Менеджер (Manager) должен иметь внутренний массив своих сотрудников (разработчиков), а также методы по удалению/добавлению разработчиков.
// Каждый Разработчик (Developer) должны иметь ссылку на Менеджера и методы для изменения менеджера (имеется ввиду возможность назначить другого менеджера).
// У класса Human должны быть следующие параметры: name (строка), age (число), dateOfBirth (строка или дата)
// У класса Employee должны присутствовать параметры: salary (число), department (строка)
// В классе Human должен присутствовать метод displayInfo, который возвращает строку со всеми параметрами экземпляра Human.
// В классе Employee должен быть реализовать такой же метод (displayInfo), который вызывает базовый метод и дополняет его параметрами из экземпляра Employee.
// Чтобы вызвать метод базового класса, необходимо внутри вызова метода displayInfo класса Employee написать: 
// super.displayInfo(), это вызовет метод disaplyInfo класс Human и вернет строку с параметрами Human'a.

class Human {
    constructor(name, age, dateOfBirth) {
      this.name = name;
      this.age = age;
      this.dateOfBirth = dateOfBirth;
    }
  
    displayInfo() {
      return `name: ${this.name} | age: ${this.age} | dateOfBirth: ${this.dateOfBirth}`;
    }
  }
  
class Employee extends Human {
    constructor(name, age, dateOfBirth, salary, department) {
      super(name, age, dateOfBirth);
      this.salary = salary;
      this.department = department;
    }
  
    displayInfo() {
      return `${super.displayInfo()} | salary: ${this.salary}$ | department: ${this.department}`;
    }
}
  
class Developer extends Employee {
    constructor(name, age, dateOfBirth, salary, department) {
      super(name, age, dateOfBirth, salary, department);
      this.manager;
      this.index;
    }
  
    changeManager(manager, developerIndex) {
      if (!!this.manager) {
        this.manager.deleteDeveloper(this.index);
      }
      this.manager = manager;
      this.index = developerIndex;
      this.manager.developers.push(this);
    }
  }
  
  class Manager extends Employee {
    constructor(name, age, dateOfBirth, salary, department) {
      super(name, age, dateOfBirth, salary, department);
      this.developers = [];
    }
  
    get newDeveloperIndex() {
      return this.developers.length;
    }
  
    addDeveloper(name, age, dateOfBirth, salary, department) {
      const newDeveloper = new Developer(
        name,
        age,
        dateOfBirth,
        salary,
        department
      );
      newDeveloper.changeManager(this, this.developers.length);
      return newDeveloper;
    }
  
    deleteDeveloper(index) {
      this.developers.splice(index, 1);
    }
  }

    
  const manager_1 = new Manager("Lev", 35, "04/10/1983", 5000, "Department 1" );
  const developer_1 = manager_1.addDeveloper("Ivan", 35, "04/10/1983", 3000, "Department 2" );
  const developer_2 = manager_1.addDeveloper( "Petr", 35, "04/10/1983", 4000, "Department 3");
  
  console.log("manager_1", manager_1);
  console.log("developer_1", developer_1);
  console.log("developer_2", developer_2);
  
  const manager_2 = new Manager( "Denis", 35, "04/10/1983", 5500, "Department 1" );
  const developer_3 = manager_2.addDeveloper("Irina", 35, "04/10/1983", 3000, "Department 2" );
  const developer_4 = manager_2.addDeveloper("Marina", 35, "04/10/1983", 3500, "Department 2" );

  console.log("manager_2", manager_2);
  console.log("developer_3", developer_3);
  console.log("developer_4", developer_4);  
  
  developer_1.changeManager(manager_2, manager_2.newDeveloperIndex);
  console.log("changeManager...");
  
  console.log("manager_1", manager_1);
  console.log("developer_2", developer_2);
  console.log("manager_2", manager_2);
  console.log("developer_1", developer_1);
  console.log("developer_3", developer_3);
  console.log("developer_4", developer_4);  

// 4*. При помощи генератора написать функцию - анкету, которая запрашивает у пользователя на ввод параметры и передаёт их в генератор. 
// В конце, когда генератор завершается, он должен вернуть все введённые входные параметры в виде объекта. Этот объект нужно вывести в консоли.

function* anketaGenerator() {
    yield prompt("Name:", "Dina");
    yield prompt("Age:", 35);
    yield prompt("Department:", "Web-Department");    
    yield prompt("Job:", "SharePoint Developer");
  }
  
  const anketaData = {};
  const anketaForm = anketaGenerator();
  
  anketaData.name = anketaForm.next().value;
  anketaData.age = anketaForm.next().value;
  anketaData.department = anketaForm.next().value;
  anketaData.job = anketaForm.next().value;
  
  console.log("anketaData", anketaData);
  
// 5*.  Написать цикл, который создаёт массив промисов, внутри каждого промиса происходит обращение к ресурсу (https://jsonplaceholder.typicode.com/users/number),
// где вместо number подставляется число от 1 до 10, в итоге должно получиться 10 промисов. 
// Следует дождаться выполнения загрузки всеми промисами и далее вывести массив загруженных данных.

const URL = "https://jsonplaceholder.typicode.com/users/";
const usersPromises = [];

for (let i = 0; i < 10; i++) {
  usersPromises[i] = fetch(`${URL}${i + 1}`).then(response => {
    return response.json();
  });
}

Promise.all(usersPromises)
  .then(users => {
    console.log("users", users);
  })
  .catch(error => {
    throw error;
  });


